from badsql.db import db, load
